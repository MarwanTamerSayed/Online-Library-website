from django.core.management.base import BaseCommand
from main.models import User

class Command(BaseCommand):
    help = 'Updates max_books to 5 for all existing users'

    def handle(self, *args, **options):
        # Update all users
        updated_count = User.objects.all().update(max_books=5)
        
        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully updated max_books to 5 for {updated_count} users'
            )
        ) 