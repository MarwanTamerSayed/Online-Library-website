// borrow_book.js
document.addEventListener("DOMContentLoaded", function() {
    // عناصر DOM
    const borrowBtn = document.querySelector('.borrow-btn');
    const bookContainer = document.querySelector('.book-container');
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.querySelector('.search-container button');

    // تحميل الكتب المستعارة عند فتح الصفحة
    loadBorrowedBooks();

    // حدث زر البحث
    if (searchBtn) {
        searchBtn.addEventListener('click', searchBorrowedBooks);
    }
    if (searchInput) {
        searchInput.addEventListener('keyup', searchBorrowedBooks);
    }

    // حدث زر الاستعارة (إذا كان موجودًا في الصفحة)
    if (borrowBtn) {
        borrowBtn.addEventListener('click', function() {
            const bookId = localStorage.getItem('selectedBookId');
            borrowBook(bookId);
        });
    }

    function loadBorrowedBooks() {
        const userId = localStorage.getItem('currentUserId');

        const allBorrowedBooks = JSON.parse(localStorage.getItem('borrowedBooks')) || [];
        const userBorrowedBooks = allBorrowedBooks;

        if (bookContainer) {
            bookContainer.innerHTML = '';

            if (userBorrowedBooks.length === 0) {
                bookContainer.innerHTML = '<p class="no-books">You have no borrowed books yet.</p>';
                return;
            }

            userBorrowedBooks.forEach(book => {
                const bookDiv = createBookElement(book);
                bookContainer.appendChild(bookDiv);
            });

            // إضافة أحداث لأزرار الإرجاع
            document.querySelectorAll('.return-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const bookId = this.getAttribute('data-book-id');
                    returnBook(bookId, userId);
                });
            });

            checkOverdueBooks();
        }
    }

    function createBookElement(book) {
        const bookDiv = document.createElement('div');
        bookDiv.className = 'book';
        bookDiv.innerHTML = `
            <img src="${book.image || 'default-book.jpg'}" alt="${book.title}" loading="lazy">
            <h3>${book.title}</h3>
            <div class="info">
                <p><strong>Author:</strong> ${book.author}</p>
                <p><strong>Borrowed Date:</strong> ${book.borrowDate}</p>
                <p class="due-date" data-due="${book.dueDate}"><strong>Due Date:</strong> ${book.dueDate}</p>
                <p><strong>Status:</strong> ${book.status || 'borrowed'}</p>
            </div>
            <button class="return-btn" data-book-id="${book.id}">Return Book</button>
        `;
        return bookDiv;
    }

    function borrowBook(bookId) {
        const userId = localStorage.getItem('currentUserId');
        if (!userId) {
            alert('Please login first');
            window.location.href = 'signup.html';
            return;
        }

        const books = JSON.parse(localStorage.getItem('books')) || [];
        const book = books.find(b => b.id === bookId);

        if (!book) {
            alert('Book not found!');
            return;
        }

        let borrowedBooks = JSON.parse(localStorage.getItem('borrowedBooks')) || [];

        const alreadyBorrowed = borrowedBooks.some(b => b.id === bookId && b.userId === userId);
        if (alreadyBorrowed) {
            alert('You have already borrowed this book!');
            return;
        }

        const today = new Date();
        const dueDate = new Date();
        dueDate.setDate(today.getDate() + 30);

        const borrowedBook = {
            ...book,
            userId: userId,
            borrowDate: today.toISOString().split('T')[0],
            dueDate: dueDate.toISOString().split('T')[0],
            status: 'borrowed'
        };

        borrowedBooks.push(borrowedBook);
        localStorage.setItem('borrowedBooks', JSON.stringify(borrowedBooks));

        alert(`"${book.title}" has been borrowed successfully. Due date: ${dueDate.toISOString().split('T')[0]}`);
        window.location.href = 'Borrowed Books.html';
    }

    // دالة إرجاع كتاب
    function returnBook(bookId, userId) {
        if (confirm('Are you sure you want to return this book?')) {
            let borrowedBooks = JSON.parse(localStorage.getItem('borrowedBooks')) || [];
            borrowedBooks = borrowedBooks.filter(book => book.id !== bookId);

            localStorage.setItem('borrowedBooks', JSON.stringify(borrowedBooks));
            alert('Book returned successfully!');
            loadBorrowedBooks();
        }
    }

    // التحقق من الكتب المتأخرة
    function checkOverdueBooks() {
        const today = new Date();
        document.querySelectorAll('.due-date').forEach(dueDateElement => {
            const dueDateStr = dueDateElement.getAttribute('data-due');
            const dueDate = new Date(dueDateStr);
            const bookDiv = dueDateElement.closest('.book');

            if (today > dueDate) {
                bookDiv.style.border = '2px solid red';
                bookDiv.querySelector('.info p:last-child').innerHTML = '<strong>Status:</strong> <span style="color:red">Overdue</span>';
            } else {
                bookDiv.style.border = '2px solid green';
            }
        });
    }

    // دالة البحث في الكتب المستعارة
    function searchBorrowedBooks() {
        const searchTerm = searchInput.value.toLowerCase();
        const userId = localStorage.getItem('currentUserId');
        const allBorrowedBooks = JSON.parse(localStorage.getItem('borrowedBooks')) || [];
        const userBorrowedBooks = allBorrowedBooks;

        if (bookContainer) {
            bookContainer.innerHTML = '';

            const filteredBooks = userBorrowedBooks.filter(book =>
                book.title.toLowerCase().includes(searchTerm) ||
                book.author.toLowerCase().includes(searchTerm)
            );

            if (filteredBooks.length === 0) {
                bookContainer.innerHTML = '<p class="no-books">No books match your search.</p>';
                return;
            }

            filteredBooks.forEach(book => {
                const bookDiv = createBookElement(book);
                bookContainer.appendChild(bookDiv);
            });

            checkOverdueBooks();
        }
    }
});