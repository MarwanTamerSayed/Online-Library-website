document.addEventListener('DOMContentLoaded', function() {
    // Get all alert messages
    const alerts = document.querySelectorAll('.alert');
    
    // Function to remove an alert
    function removeAlert(alert) {
        alert.style.opacity = '0';
        setTimeout(() => {
            alert.style.display = 'none';
        }, 300); // Wait for fade out animation
    }

    // Add fade out animation to alerts
    alerts.forEach(alert => {
        // Add transition for smooth fade out
        alert.style.transition = 'opacity 0.3s ease-in-out';
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            removeAlert(alert);
        }, 5000);

        // Close button click handler
        const closeBtn = alert.querySelector('.close-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                removeAlert(alert);
            });
        }
    });
}); 