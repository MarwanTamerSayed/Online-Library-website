from django import forms
from django.contrib.auth.models import User
from .models import Book
import re

from django.contrib.auth import get_user_model

User = get_user_model()
class SignupForm(forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'your-input-class'})
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'your-input-class'})
    )
    status = forms.ChoiceField(
        choices=[('admin', 'Admin'), ('user', 'User')],
        widget=forms.RadioSelect(attrs={'class': 'your-radio-class'})
    )

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'username', 'password']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'your-input-class'}),
            'last_name': forms.TextInput(attrs={'class': 'your-input-class'}),
            'email': forms.EmailInput(attrs={'class': 'your-input-class'}),
            'username': forms.TextInput(attrs={'class': 'your-input-class'}),
        }

    def clean_email(self):
        email = self.cleaned_data.get('email')
        email_pattern = re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
        if not email_pattern.match(email):
            raise forms.ValidationError("Please enter a valid email address.")
        return email

    def clean_password(self):
        password = self.cleaned_data.get('password')
        password_pattern = re.compile(r'^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$')
        if not password_pattern.match(password):
            raise forms.ValidationError(
                "Password must be at least 8 characters and include uppercase, lowercase, and a number."
            )
        return password

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm = cleaned_data.get('confirm_password')

        if password and confirm and password != confirm:
            self.add_error('confirm_password', "Passwords do not match.")


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'category', 'description', 'image', 'quantity']
  