from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .forms import SignupForm
from .models import Book, BorrowedBook
from .forms import BookForm
from django.contrib.auth import get_user_model
from django.shortcuts import render, get_object_or_404


def home(request):
    return render(request, 'home.html', {'is_admin': request.user.is_superuser})


User = get_user_model()


def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])

            # ✅ Set admin role based on 'status'
            if form.cleaned_data.get('status') == 'admin':
                user.is_superuser = True
                user.is_staff = True  # Optional: allows access to Django admin site
            else:
                user.is_superuser = False
                user.is_staff = False

            user.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            username = User.objects.get(email=email).username
        except User.DoesNotExist:
            return render(request, 'login.html', {'error': 'User not found'})

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            # ✅ Send everyone to user_home
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})

    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


def book_list(request):
    search_query = request.GET.get('search', '')
    if search_query:
        books = Book.objects.filter(title__icontains=search_query) | Book.objects.filter(
            author__icontains=search_query) | Book.objects.filter(category__icontains=search_query)
    else:
        books = Book.objects.all()
    
    # Get user's currently borrowed books
    user_borrowed_books = set()
    if request.user.is_authenticated:
        user_borrowed_books = set(BorrowedBook.objects.filter(
            user=request.user, 
            returned=False
        ).values_list('book_id', flat=True))
    
    # Prefetch borrowed books information and calculate status
    books_with_status = []
    for book in books:
        # Only count non-returned books for availability
        active_borrows = BorrowedBook.objects.filter(book=book, returned=False).count()
        available_copies = book.quantity - active_borrows
        
        books_with_status.append({
            'book': book,
            'active_borrows': active_borrows,
            'available_copies': available_copies,
            'is_borrowed_by_user': book.id in user_borrowed_books
        })
    
    return render(request, 'book_list.html', {
        'books_with_status': books_with_status,
        'is_admin': request.user.is_superuser
    })


@login_required
def add_book(request):
    if not request.user.is_superuser:
        return redirect('user_home')

    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()

    # Get all books with their borrowed information
    books = Book.objects.all().prefetch_related('borrowedbook_set')
    
    # Create a list of books with their borrowed status
    books_with_info = []
    for book in books:
        current_borrowers = book.borrowedbook_set.filter(returned=False)
        borrower_count = current_borrowers.count()
        
        books_with_info.append({
            'book': book,
            'borrower_count': borrower_count,
            'is_borrowed': borrower_count > 0
        })
    
    return render(request, 'add_book.html', {
        'form': form,
        'books_info': books_with_info
    })


def book_details(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    return render(request, 'book_details.html', {'book': book})


@login_required
def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == "POST":
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm(instance=book)
    return render(request, 'edit_book.html', {'form': form, 'book': book})


@login_required
def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == "POST":
        book.delete()
        return redirect('book_list')
    return render(request, 'confirm_delete.html', {'book': book})


def about(request):
    return render(request, 'Aboutus.html')


# views.py

@login_required
def borrowed_books(request):
    borrowed_books = BorrowedBook.objects.filter(user=request.user, returned=False)
    return render(request, 'borrowed_books.html', {'borrowed_books': borrowed_books})


@login_required
def return_book(request, borrowed_id):
    if request.method == 'POST':
        borrowed_book = get_object_or_404(BorrowedBook, id=borrowed_id, user=request.user)
        borrowed_book.returned = True
        borrowed_book.save()
        
        # Update book availability in book list
        book = borrowed_book.book
        active_borrows = book.borrowedbook_set.filter(returned=False).count()
        if active_borrows < book.quantity:
            book.save()  # Trigger update of book status
            
    return redirect('borrowed_books')


@login_required
def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    
    # Check if the book has available copies
    active_borrows = book.borrowedbook_set.filter(returned=False).count()
    if active_borrows >= book.quantity:
        # You might want to add a message here to inform the user
        return redirect('book_list')

    # Check if the book is already borrowed by the user
    if BorrowedBook.objects.filter(user=request.user, book=book, returned=False).exists():
        return redirect('borrowed_books')

    # Create a BorrowedBook entry for the user
    BorrowedBook.objects.create(user=request.user, book=book)

    return redirect('borrowed_books')
