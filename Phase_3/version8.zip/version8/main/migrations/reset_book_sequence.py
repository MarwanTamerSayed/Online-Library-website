from django.db import migrations

def reset_sequence(apps, schema_editor):
    # Get database connection
    if schema_editor.connection.vendor == 'sqlite':
        # For SQLite
        schema_editor.execute("DELETE FROM sqlite_sequence WHERE name='main_book';")
    elif schema_editor.connection.vendor == 'postgresql':
        # For PostgreSQL
        schema_editor.execute("ALTER SEQUENCE main_book_id_seq RESTART WITH 1;")

class Migration(migrations.Migration):
    dependencies = [
        ('main', '0005_book_quantity'),  # تأكدي من رقم آخر migration موجود
    ]

    operations = [
        migrations.RunPython(reset_sequence),
    ] 