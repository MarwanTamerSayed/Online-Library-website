// Global message system
const MessageSystem = {
    init() {
        // Create messages container if it doesn't exist
        if (!document.querySelector('.messages')) {
            const container = document.createElement('div');
            container.className = 'messages';
            // Insert after header or at the start of body
            const header = document.querySelector('header');
            if (header) {
                header.after(container);
            } else {
                document.body.prepend(container);
            }
        }
    },

    show(message, type = 'info') {
        this.init();
        const container = document.querySelector('.messages');
        
        // Create alert element
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `
            ${message}
            <button type="button" class="close-btn" onclick="this.parentElement.remove();">&times;</button>
        `;
        
        // Add fade-in effect
        alert.style.opacity = '0';
        container.appendChild(alert);
        
        // Trigger fade in
        setTimeout(() => {
            alert.style.opacity = '1';
        }, 10);
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    }
};

// Make it available globally
window.showMessage = MessageSystem.show.bind(MessageSystem); 