from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .forms import SignupForm
from .models import Book ,BorrowedBook
from .forms import BookForm
from django.contrib.auth import get_user_model
from django.shortcuts import render, get_object_or_404



def home(request):
    return render(request, 'home.html', {'is_admin': request.user.is_superuser})


User = get_user_model() 
def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])

            # ✅ Set admin role based on 'status'
            if form.cleaned_data.get('status') == 'admin':
                user.is_superuser = True
                user.is_staff = True  # Optional: allows access to Django admin site
            else:
                user.is_superuser = False
                user.is_staff = False

            user.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})



def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            username = User.objects.get(email=email).username
        except User.DoesNotExist:
            return render(request, 'login.html', {'error': 'User not found'})
        
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            # ✅ Send everyone to user_home
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


def book_list(request):
    search_query = request.GET.get('search', '')
    if search_query:
        books = Book.objects.filter(title__icontains=search_query) | Book.objects.filter(author__icontains=search_query) | Book.objects.filter(category__icontains=search_query)
    else:
        books = Book.objects.all()
    return render(request, 'book_list.html', {'books': books})


@login_required
def add_book(request):
    if not request.user.is_superuser:
        return redirect('user_home')  # Or handle unauthorized access appropriately

    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('book_list')  # Redirect to the book list after adding
    else:
        form = BookForm()

    books = Book.objects.all()  # Fetch books from database
    return render(request, 'add_book.html', {'form': form, 'books': books})

def book_details(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    return render(request, 'book_details.html', {'book': book})

@login_required
def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == "POST":
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm(instance=book)
    return render(request, 'edit_book.html', {'form': form, 'book': book})

@login_required
def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == "POST":
        book.delete()
        return redirect('book_list')
    return render(request, 'confirm_delete.html', {'book': book})


def about(request):
    return render(request, 'Aboutus.html')

# views.py

@login_required
def borrowed_books(request):
    borrowed_books = BorrowedBook.objects.filter(user=request.user)

    return render(request, 'borrowed_books.html', {'borrowed_books': borrowed_books})


@login_required
def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)

    # Check if the book is already borrowed by the user
    if BorrowedBook.objects.filter(user=request.user, book=book).exists():
        return redirect('borrowed_books')  # Optionally show a message that the book is already borrowed.

    # Create a BorrowedBook entry for the user
    BorrowedBook.objects.create(user=request.user, book=book)

    # Redirect to the borrowed books page
    return redirect('borrowed_books')


def return_book(request, borrowed_id):
    borrowed_book = get_object_or_404(BorrowedBook, id=borrowed_id)
    
    if borrowed_book.user == request.user:  # Ensure only the correct user can return their own book
        borrowed_book.returned = True  # Assuming you have a `returned` field in your BorrowedBook model
        borrowed_book.save()
        
    return redirect('borrowed_books')  # Redirect back to the borrowed books page