from django.core.management.base import BaseCommand
from main.models import Book, BorrowedBook

class Command(BaseCommand):
    help = 'Reset books table and its ID sequence'

    def handle(self, *args, **options):
        # Delete all borrowed books first (because of foreign key)
        BorrowedBook.objects.all().delete()
        
        # Delete all books
        Book.objects.all().delete()
        
        self.stdout.write(self.style.SUCCESS('Successfully reset books table')) 