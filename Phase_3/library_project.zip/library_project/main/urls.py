from django.urls import path
from . import views

urlpatterns = [
    path('', views.user_home, name='user_home'),
    path('admin_home/', views.admin_home, name='admin_home'),
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('book_list/', views.book_list, name='book_list'),
    path('add_book/', views.add_book, name='add_book'),
]
