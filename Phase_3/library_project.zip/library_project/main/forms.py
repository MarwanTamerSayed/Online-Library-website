from django import forms
from django.contrib.auth.models import User
from .models import Book

from django.contrib.auth import get_user_model

User = get_user_model()
class SignupForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    confirm_password = forms.CharField(widget=forms.PasswordInput())
    status = forms.ChoiceField(choices=[('admin', 'Admin'), ('user', 'User')], widget=forms.RadioSelect)

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'username', 'password', 'status']


    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('password') != cleaned_data.get('confirm_password'):
            self.add_error('confirm_password', "Passwords do not match.")



class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'category', 'description']  # Add 'cover_image' if applicable