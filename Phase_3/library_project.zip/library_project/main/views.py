from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .forms import SignupForm
from .models import Book

def user_home(request):
    return render(request, 'user_home.html')

@login_required
def admin_home(request):
    if request.user.is_superuser:  # or check for a custom role
        return render(request, 'admin_home.html')
    return render(request, 'user_home.html')  # fallback

def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            return redirect('login')
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            username = User.objects.get(email=email).username
        except User.DoesNotExist:
            return render(request, 'login.html', {'error': 'User not found'})
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')  # or any page
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')


def book_list(request):
    search_query = request.GET.get('search', '')
    if search_query:
        books = Book.objects.filter(title__icontains=search_query) | Book.objects.filter(author__icontains=search_query) | Book.objects.filter(category__icontains=search_query)
    else:
        books = Book.objects.all()
    return render(request, 'book_list.html', {'books': books})
